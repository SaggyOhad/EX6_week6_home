#pragma once

void part1();