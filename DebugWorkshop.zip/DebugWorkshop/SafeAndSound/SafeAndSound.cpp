#include "part1.h"
#include "part2.h"

int main()
{
	part1();

	//part2();	// debug this after the completion of part1

	return 0;
}
